import main
print("\n Perhitungan Luas Bangun datar")

print()
print("## Perhitungan Luas & Keliling Persegi")

main.l_persegi(15)
main.l_persegi(4)

print()
print("## Perhitungan Luas & Keliling Persegi Panjang")

main.persegi_panjang(15,12)

print()
print("## Perhitungan luas Segitiga")

main.l_segita(8,2)

print()
print("## Perhitungan luas Lingkaran")

main.l_lingkaran(10,6)

print()
print("## Perhitungan luas Jajar genjang")

main.l_jajar_genjang(8,2)

print("\n Perhitungan Luas Bangun ruang")

print()
print("## Perhitungan luas kubus")

main.l_kubus (8)

print()
print("## Perhitungan luas balok")

main.l_balok (7,5,2)

print()
print("## Perhitungan luas tabung")

main.l_tabung (6,3)

print()
print("## Perhitungan luas kerucut")

main.l_kerucut (5,3)

print()
print("## Perhitungan luas bola")

main.l_bola (6)